import Vue from 'vue'
import VWave from 'v-wave'

Vue.use(VWave, {})
